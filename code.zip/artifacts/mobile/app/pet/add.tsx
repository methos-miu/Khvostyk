import { MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { Image } from "expo-image";
import { router } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  PanResponder,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import Animated, { FadeIn, FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import * as FileSystem from "expo-file-system/legacy";
import { supabase } from "@/lib/supabase";
import { Colors } from "@/constants/colors";
import {
  CAT_BREEDS_UK, CAT_BREEDS_EN,
  DOG_BREEDS_UK, DOG_BREEDS_EN,
  RABBIT_BREEDS_UK, RABBIT_BREEDS_EN,
  HAMSTER_BREEDS_UK, HAMSTER_BREEDS_EN,
  GUINEA_PIG_BREEDS_UK, GUINEA_PIG_BREEDS_EN,
  BIRD_SPECIES_UK, BIRD_SPECIES_EN,
  TURTLE_BREEDS_UK, TURTLE_BREEDS_EN,
  REPTILE_BREEDS_UK, REPTILE_BREEDS_EN,
  FISH_BREEDS_UK, FISH_BREEDS_EN,
  FERRET_TYPES_UK, FERRET_TYPES_EN,
  HEDGEHOG_BREEDS_UK, HEDGEHOG_BREEDS_EN,
} from "@/constants/breeds";
import { Species, Gender, usePets } from "@/context/PetsContext";
import { useLanguage } from "@/context/LanguageContext";
import { DatePickerField } from "@/components/ui/DatePickerField";
import { BreedPickerModal } from "@/components/ui/BreedPickerModal";
import { AnimalPickerModal } from "@/components/ui/AnimalPickerModal";
import { getAnimalEmoji, getAnimalName, legacySpeciesKey } from "@/constants/animals";

type FormData = {
  name: string;
  species: Species;
  customSpecies: string;
  breed: string;
  birthdate: string;
  weight: string;
  length: string;
  height: string;
  color: string;
  photoUri: string;
  gender: Gender;
  personality: string;
  description: string;
};


const WEIGHT_VALUES = Array.from({ length: 1000 }, (_, i) =>
  ((i + 1) * 0.1).toFixed(1)
);
const LENGTH_VALUES = Array.from({ length: 200 }, (_, i) => String(i + 1));
const HEIGHT_VALUES = Array.from({ length: 200 }, (_, i) => String(i + 1));

const ITEM_HEIGHT = 44;

function getBreedList(species: Species, lang: "uk" | "en"): string[] {
  const uk = lang === "uk";
  switch (species) {
    case "cat":       return uk ? CAT_BREEDS_UK       : CAT_BREEDS_EN;
    case "dog":       return uk ? DOG_BREEDS_UK       : DOG_BREEDS_EN;
    case "rabbit":    return uk ? RABBIT_BREEDS_UK    : RABBIT_BREEDS_EN;
    case "hamster":   return uk ? HAMSTER_BREEDS_UK   : HAMSTER_BREEDS_EN;
    case "guinea_pig":return uk ? GUINEA_PIG_BREEDS_UK: GUINEA_PIG_BREEDS_EN;
    case "bird":      return uk ? BIRD_SPECIES_UK     : BIRD_SPECIES_EN;
    case "turtle":    return uk ? TURTLE_BREEDS_UK    : TURTLE_BREEDS_EN;
    case "reptile":   return uk ? REPTILE_BREEDS_UK   : REPTILE_BREEDS_EN;
    case "fish":      return uk ? FISH_BREEDS_UK      : FISH_BREEDS_EN;
    case "ferret":    return uk ? FERRET_TYPES_UK     : FERRET_TYPES_EN;
    case "hedgehog":  return uk ? HEDGEHOG_BREEDS_UK  : HEDGEHOG_BREEDS_EN;
    default:          return [];
  }
}

export default function AddPetScreen() {
  const { addPet, upsertBirthdayEvent } = usePets();
  const { t, language } = useLanguage();
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(false);
  const [showBreedPicker, setShowBreedPicker] = useState(false);
  const [showWeightPicker, setShowWeightPicker] = useState(false);
  const [showLengthPicker, setShowLengthPicker] = useState(false);
  const [showHeightPicker, setShowHeightPicker] = useState(false);
  const [showAnimalPicker, setShowAnimalPicker] = useState(false);
  const [selectedWeight, setSelectedWeight] = useState("5.0");
  const [selectedLength, setSelectedLength] = useState("30");
  const [selectedHeight, setSelectedHeight] = useState("30");
  const [keyboardVisible, setKeyboardVisible] = useState(false);

  useEffect(() => {
    const show = Keyboard.addListener("keyboardDidShow", () => setKeyboardVisible(true));
    const hide = Keyboard.addListener("keyboardDidHide", () => setKeyboardVisible(false));
    return () => { show.remove(); hide.remove(); };
  }, []);

  const [form, setForm] = useState<FormData>({
    name: "",
    species: "cat",
    customSpecies: "",
    breed: "",
    birthdate: "",
    weight: "",
    length: "",
    height: "",
    color: "",
    photoUri: "",
    gender: null,
    personality: "",
    description: "",
  });

  const updateForm = (key: keyof FormData, value: any) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const pickPhoto = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.85,
    });
    if (!result.canceled && result.assets[0]) {
      updateForm("photoUri", result.assets[0].uri);
    }
  };

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert(t.permissionTitle, t.cameraDenied);
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.85,
    });
    if (!result.canceled && result.assets[0]) {
      updateForm("photoUri", result.assets[0].uri);
    }
  };

  const showPhotoOptions = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert(t.photoTitle, "", [
      { text: t.photoCamera, onPress: takePhoto },
      { text: t.photoGallery, onPress: pickPhoto },
      { text: t.cancel, style: "cancel" },
    ]);
  };

  const handleSave = async () => {
    if (!form.name.trim()) {
      Alert.alert("", t.errorName);
      return;
    }
    if (!form.birthdate.trim()) {
      Alert.alert("", t.errorBirthdate);
      return;
    }
    if (form.species === "other" && !form.customSpecies.trim()) {
      Alert.alert("", language === "uk" ? "Вкажіть назву тварини" : "Please enter the animal name");
      return;
    }
    setLoading(true);
    try {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      let photoUrl = form.photoUri;
      if (form.photoUri && form.photoUri.startsWith("file")) {
        const { data: { user } } = await supabase.auth.getUser();
        const uid = user?.id;
        if (uid) {
          const ext = form.photoUri.split(".").pop() ?? "jpg";
          const fileName = `${uid}/${Date.now()}.${ext}`;
          const base64 = await FileSystem.readAsStringAsync(form.photoUri, { encoding: "base64" });
          const binary = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
          const { data, error } = await supabase.storage.from("pet-photos").upload(fileName, binary, { contentType: "image/jpeg" });
          if (!error && data) {
            photoUrl = data.path;
            const { data: signedData } = await supabase.storage.from("pet-photos").createSignedUrl(data.path, 3600);
            if (signedData?.signedUrl) photoUrl = signedData.signedUrl;
          }
        }
      }
      const newPet = await addPet({
        name: form.name.trim(),
        species: form.species,
        customSpecies: form.species === "other" ? form.customSpecies.trim() : undefined,
        breed: form.breed.trim(),
        birthdate: form.birthdate,
        weight: form.weight.trim(),
        color: form.color.trim(),
        photoUri: photoUrl,
        gender: form.gender,
        length: form.length ? Number(form.length) : undefined,
        height: form.height ? Number(form.height) : undefined,
        personality: form.personality.trim() || undefined,
        description: form.description.trim() || undefined,
      });
      if (form.birthdate) {
        const bdTitle = language === "uk" ? "День народження" : "Birthday";
        await upsertBirthdayEvent(newPet.id, form.birthdate, bdTitle);
      }
      router.back();
    } finally {
      setLoading(false);
    }
  };

  const breedList = getBreedList(form.species, language);
  const showBreedOption = form.species !== "other";

  const weightIndex = Math.max(0, WEIGHT_VALUES.indexOf(selectedWeight));

  const weightPanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, gs) => gs.dy > 2,
      onPanResponderRelease: (_, gs) => {
        if (gs.dy > 50) setShowWeightPicker(false);
      },
    })
  ).current;

  const onWeightScrollEnd = (event: any) => {
    const offset = event.nativeEvent.contentOffset.y;
    const index = Math.max(0, Math.min(Math.round(offset / ITEM_HEIGHT), WEIGHT_VALUES.length - 1));
    const newWeight = WEIGHT_VALUES[index];
    if (newWeight !== selectedWeight) {
      Haptics.selectionAsync();
      setSelectedWeight(newWeight);
    }
  };

  const openWeightPicker = () => {
    const init = form.weight && WEIGHT_VALUES.includes(form.weight) ? form.weight : WEIGHT_VALUES[49];
    setSelectedWeight(init);
    setShowWeightPicker(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const confirmWeight = () => {
    updateForm("weight", selectedWeight);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowWeightPicker(false);
  };

  const lengthPanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, gs) => gs.dy > 2,
      onPanResponderRelease: (_, gs) => { if (gs.dy > 50) setShowLengthPicker(false); },
    })
  ).current;

  const heightPanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, gs) => gs.dy > 2,
      onPanResponderRelease: (_, gs) => { if (gs.dy > 50) setShowHeightPicker(false); },
    })
  ).current;

  const onLengthScrollEnd = (event: any) => {
    const index = Math.max(0, Math.min(Math.round(event.nativeEvent.contentOffset.y / ITEM_HEIGHT), LENGTH_VALUES.length - 1));
    const v = LENGTH_VALUES[index];
    if (v !== selectedLength) { Haptics.selectionAsync(); setSelectedLength(v); }
  };

  const onHeightScrollEnd = (event: any) => {
    const index = Math.max(0, Math.min(Math.round(event.nativeEvent.contentOffset.y / ITEM_HEIGHT), HEIGHT_VALUES.length - 1));
    const v = HEIGHT_VALUES[index];
    if (v !== selectedHeight) { Haptics.selectionAsync(); setSelectedHeight(v); }
  };

  const openLengthPicker = () => {
    const init = form.length && LENGTH_VALUES.includes(form.length) ? form.length : "30";
    setSelectedLength(init);
    setShowLengthPicker(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const confirmLength = () => {
    updateForm("length", selectedLength);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowLengthPicker(false);
  };

  const openHeightPicker = () => {
    const init = form.height && HEIGHT_VALUES.includes(form.height) ? form.height : "30";
    setSelectedHeight(init);
    setShowHeightPicker(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const confirmHeight = () => {
    updateForm("height", selectedHeight);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowHeightPicker(false);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      {/* Top bar */}
      <View style={styles.topBar}>
        <View style={styles.handleWrap}>
          <View style={styles.modalHandle} />
        </View>
        <View style={styles.modalHeader}>
          <Pressable onPress={() => router.back()} hitSlop={8}>
            <Text style={styles.modalCancel}>{language === "uk" ? "Скасувати" : "Cancel"}</Text>
          </Pressable>
          <Text style={styles.modalTitle}>{language === "uk" ? "Нова тварина" : "New Pet"}</Text>
          <Pressable onPress={handleSave} disabled={loading} hitSlop={8}>
            <Text style={[styles.modalSave, loading && { opacity: 0.4 }]}>
              {language === "uk" ? "Зберегти" : "Save"}
            </Text>
          </Pressable>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets={false}
        scrollEnabled={true}
        bounces={true}
      >
        <Animated.View entering={FadeIn.delay(80)}>
          {/* Photo */}
          <Pressable onPress={showPhotoOptions} style={styles.photoButton}>
            {form.photoUri ? (
              <Image source={{ uri: form.photoUri }} style={styles.photoPreview} contentFit="cover" />
            ) : (
              <View style={styles.photoPlaceholder}>
                <MaterialCommunityIcons name="camera-outline" size={36} color={Colors.primary} />
                <Text style={styles.photoPlaceholderText}>{t.addPet}</Text>
              </View>
            )}
            <View style={styles.photoBadge}>
              <MaterialCommunityIcons name="camera" size={14} color={Colors.textLight} />
            </View>
          </Pressable>

          {/* Species — 3-button picker */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>{t.petType}</Text>
            <View style={styles.mainSpeciesRow}>
              {/* Cat */}
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  updateForm("species", "cat");
                  updateForm("customSpecies", "");
                  updateForm("breed", "");
                }}
                style={[styles.mainSpeciesBtn, form.species === "cat" && styles.mainSpeciesBtnActive]}
              >
                <Text style={styles.mainSpeciesEmoji}>🐱</Text>
                <Text style={[styles.mainSpeciesLabel, form.species === "cat" && styles.mainSpeciesLabelActive]}>
                  {language === "uk" ? "Кіт" : "Cat"}
                </Text>
              </Pressable>

              {/* Dog */}
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  updateForm("species", "dog");
                  updateForm("customSpecies", "");
                  updateForm("breed", "");
                }}
                style={[styles.mainSpeciesBtn, form.species === "dog" && styles.mainSpeciesBtnActive]}
              >
                <Text style={styles.mainSpeciesEmoji}>🐶</Text>
                <Text style={[styles.mainSpeciesLabel, form.species === "dog" && styles.mainSpeciesLabelActive]}>
                  {language === "uk" ? "Собака" : "Dog"}
                </Text>
              </Pressable>

              {/* Other — opens animal picker */}
              <Pressable
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setShowAnimalPicker(true);
                }}
                style={[styles.mainSpeciesBtn, form.species === "other" && styles.mainSpeciesBtnActive]}
              >
                {form.species === "other" && form.customSpecies ? (
                  <>
                    <Text style={styles.mainSpeciesEmoji}>{getAnimalEmoji("other", form.customSpecies)}</Text>
                    <Text style={[styles.mainSpeciesLabel, styles.mainSpeciesLabelActive]} numberOfLines={2}>
                      {getAnimalName("other", form.customSpecies, language)}
                    </Text>
                  </>
                ) : (
                  <>
                    <Text style={styles.mainSpeciesEmoji}>🔍</Text>
                    <Text style={[styles.mainSpeciesLabel, form.species === "other" && styles.mainSpeciesLabelActive]}>
                      {language === "uk" ? "Інше" : "Other"}
                    </Text>
                  </>
                )}
              </Pressable>
            </View>
          </View>

          {/* Gender */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>{t.gender}</Text>
            <View style={styles.genderRow}>
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  updateForm("gender", form.gender === "male" ? null : "male");
                }}
                style={[styles.genderOption, form.gender === "male" && styles.genderMaleActive]}
              >
                <MaterialCommunityIcons name="gender-male" size={20} color={form.gender === "male" ? Colors.textLight : Colors.primary} />
                <Text style={[styles.genderLabel, form.gender === "male" && styles.genderLabelActive]}>
                  {t.male}
                </Text>
              </Pressable>
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  updateForm("gender", form.gender === "female" ? null : "female");
                }}
                style={[styles.genderOption, form.gender === "female" && styles.genderFemaleActive]}
              >
                <MaterialCommunityIcons name="gender-female" size={20} color={form.gender === "female" ? Colors.textLight : "#E91E63"} />
                <Text style={[styles.genderLabel, form.gender === "female" && styles.genderLabelActive]}>
                  {t.female}
                </Text>
              </Pressable>
            </View>
          </View>

          {/* Main Info */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>{t.basicInfo}</Text>
            <View style={styles.card}>
              {/* Name */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{t.name} *</Text>
                <TextInput
                  style={styles.input}
                  value={form.name}
                  onChangeText={(v) => updateForm("name", v)}
                  placeholder={t.namePlaceholder}
                  placeholderTextColor={Colors.textTertiary}
                />
              </View>
              <View style={styles.divider} />

              {/* Breed */}
              {showBreedOption ? (
                <>
                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setShowBreedPicker(true);
                    }}
                    style={styles.inputGroup}
                  >
                    <Text style={styles.inputLabel}>{t.breed}</Text>
                    <View style={styles.pickerRow}>
                      <Text style={[styles.input, !form.breed && { color: Colors.textTertiary }]} numberOfLines={1}>
                        {form.breed || t.breedPlaceholder}
                      </Text>
                      <MaterialCommunityIcons name="chevron-down" size={16} color={Colors.textTertiary} />
                    </View>
                  </Pressable>
                  <View style={styles.divider} />
                </>
              ) : (
                <>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>{t.breed}</Text>
                    <TextInput
                      style={styles.input}
                      value={form.breed}
                      onChangeText={(v) => updateForm("breed", v)}
                      placeholder={t.breedPlaceholder}
                      placeholderTextColor={Colors.textTertiary}
                    />
                  </View>
                  <View style={styles.divider} />
                </>
              )}

              {/* Birthdate — calendar picker */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{t.birthdate} *</Text>
                <DatePickerField
                  value={form.birthdate}
                  onChange={(iso) => updateForm("birthdate", iso)}
                  placeholder={language === "uk" ? "Оберіть дату народження" : "Select birth date"}
                  label={t.birthdate}
                  maximumDate={new Date()}
                />
              </View>
              <View style={styles.divider} />

              {/* Weight picker */}
              <Pressable
                onPress={openWeightPicker}
                style={styles.inputGroup}
              >
                <Text style={styles.inputLabel}>{t.weight}</Text>
                <View style={styles.pickerRow}>
                  <Text style={[styles.input, !form.weight && { color: Colors.textTertiary }]}>
                    {form.weight ? `${form.weight} кг` : "— кг"}
                  </Text>
                  <MaterialCommunityIcons name="chevron-down" size={16} color={Colors.textTertiary} />
                </View>
              </Pressable>
              <View style={styles.divider} />

              {/* Color */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{t.color}</Text>
                <TextInput
                  style={styles.input}
                  value={form.color}
                  onChangeText={(v) => updateForm("color", v)}
                  placeholder={t.colorPlaceholder}
                  placeholderTextColor={Colors.textTertiary}
                />
              </View>
              <View style={styles.divider} />

              {/* Length */}
              <Pressable onPress={openLengthPicker} style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{language === "uk" ? "Довжина (см)" : "Length (cm)"}</Text>
                <View style={styles.pickerRow}>
                  <Text style={[styles.input, !form.length && { color: Colors.textTertiary }]}>
                    {form.length ? `${form.length} см` : "— см"}
                  </Text>
                  <MaterialCommunityIcons name="chevron-down" size={16} color={Colors.textTertiary} />
                </View>
              </Pressable>
              <View style={styles.divider} />

              {/* Height */}
              <Pressable onPress={openHeightPicker} style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{language === "uk" ? "Висота (см)" : "Height (cm)"}</Text>
                <View style={styles.pickerRow}>
                  <Text style={[styles.input, !form.height && { color: Colors.textTertiary }]}>
                    {form.height ? `${form.height} см` : "— см"}
                  </Text>
                  <MaterialCommunityIcons name="chevron-down" size={16} color={Colors.textTertiary} />
                </View>
              </Pressable>
            </View>
          </View>

          {/* Personality & Description */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>{language === "uk" ? "Характер та опис" : "Personality & Description"}</Text>
            <View style={styles.card}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{language === "uk" ? "Характер" : "Personality"}</Text>
                <TextInput
                  style={[styles.input, { minHeight: 44 }]}
                  value={form.personality}
                  onChangeText={(v) => updateForm("personality", v)}
                  placeholder={language === "uk" ? "Напр. грайливий, лагідний, активний" : "e.g. playful, gentle, active"}
                  placeholderTextColor={Colors.textTertiary}
                  multiline
                />
              </View>
              <View style={styles.divider} />
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{language === "uk" ? "Опис" : "Description"}</Text>
                <TextInput
                  style={[styles.input, { minHeight: 44 }]}
                  value={form.description}
                  onChangeText={(v) => updateForm("description", v)}
                  placeholder={language === "uk" ? "Додаткова інформація про тварину" : "Additional information about the pet"}
                  placeholderTextColor={Colors.textTertiary}
                  multiline
                />
              </View>
            </View>
          </View>

          {/* Save */}
          <Pressable
            onPress={handleSave}
            disabled={loading}
            style={[styles.saveButton, loading && styles.saveButtonDisabled]}
          >
            <Text style={styles.saveButtonText}>
              {loading ? t.saving : t.save}
            </Text>
          </Pressable>
        </Animated.View>
      </ScrollView>

      <BreedPickerModal
        visible={showBreedPicker}
        onClose={() => setShowBreedPicker(false)}
        breeds={breedList}
        selectedBreed={form.breed}
        onSelect={(breed) => updateForm("breed", breed)}
        title={t.selectBreed}
        language={language}
      />

      <AnimalPickerModal
        visible={showAnimalPicker}
        language={language}
        onClose={() => setShowAnimalPicker(false)}
        onSelect={(key) => {
          updateForm("species", "other");
          updateForm("customSpecies", key);
          updateForm("breed", "");
          setShowAnimalPicker(false);
        }}
        onCustom={(name) => {
          updateForm("species", "other");
          updateForm("customSpecies", name);
          updateForm("breed", "");
          setShowAnimalPicker(false);
        }}
      />

      {/* Weight Picker Modal */}
      <Modal
        visible={showWeightPicker}
        animationType="slide"
        transparent
        onRequestClose={() => setShowWeightPicker(false)}
      >
        <View style={styles.modalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setShowWeightPicker(false)} />
          <Animated.View entering={FadeInDown.springify()} style={[styles.modalSheet, styles.weightModalSheet]}>
            <View {...weightPanResponder.panHandlers} style={styles.handleWrap}>
              <View style={styles.modalHandle} />
            </View>
            <View style={styles.modalHeader}>
              <Pressable onPress={() => setShowWeightPicker(false)}>
                <Text style={styles.modalCancel}>{language === "uk" ? "Скасувати" : "Cancel"}</Text>
              </Pressable>
              <Text style={styles.modalTitle}>{t.weightSelect}</Text>
              <Pressable onPress={confirmWeight}>
                <Text style={styles.modalSave}>{language === "uk" ? "Зберегти" : "Save"}</Text>
              </Pressable>
            </View>
            <View style={styles.weightPickerContainer}>
              <View style={styles.weightSelectionBar} />
              <FlatList
                data={WEIGHT_VALUES}
                keyExtractor={(item) => item}
                showsVerticalScrollIndicator={false}
                snapToInterval={ITEM_HEIGHT}
                decelerationRate="fast"
                contentContainerStyle={{ paddingVertical: ITEM_HEIGHT * 2 }}
                initialScrollIndex={weightIndex}
                getItemLayout={(_, index) => ({
                  length: ITEM_HEIGHT,
                  offset: ITEM_HEIGHT * index,
                  index,
                })}
                onScrollEndDrag={onWeightScrollEnd}
                onMomentumScrollEnd={onWeightScrollEnd}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => { Haptics.selectionAsync(); setSelectedWeight(item); }}
                    style={styles.weightItem}
                  >
                    <Text style={[
                      styles.weightItemText,
                      selectedWeight === item && styles.weightItemTextActive,
                    ]}>
                      {item} кг
                    </Text>
                  </Pressable>
                )}
              />
            </View>
          </Animated.View>
        </View>
      </Modal>
      {/* Length Picker Modal */}
      <Modal visible={showLengthPicker} animationType="slide" transparent onRequestClose={() => setShowLengthPicker(false)}>
        <View style={styles.modalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setShowLengthPicker(false)} />
          <Animated.View entering={FadeInDown.springify()} style={[styles.modalSheet, styles.weightModalSheet]}>
            <View {...lengthPanResponder.panHandlers} style={styles.handleWrap}>
              <View style={styles.modalHandle} />
            </View>
            <View style={styles.modalHeader}>
              <Pressable onPress={() => setShowLengthPicker(false)}>
                <Text style={styles.modalCancel}>{language === "uk" ? "Скасувати" : "Cancel"}</Text>
              </Pressable>
              <Text style={styles.modalTitle}>{language === "uk" ? "Довжина" : "Length"}</Text>
              <Pressable onPress={confirmLength}>
                <Text style={styles.modalSave}>{language === "uk" ? "Зберегти" : "Save"}</Text>
              </Pressable>
            </View>
            <View style={styles.weightPickerContainer}>
              <View style={styles.weightSelectionBar} />
              <FlatList
                data={LENGTH_VALUES}
                keyExtractor={(item) => item}
                showsVerticalScrollIndicator={false}
                snapToInterval={ITEM_HEIGHT}
                decelerationRate="fast"
                contentContainerStyle={{ paddingVertical: ITEM_HEIGHT * 2 }}
                initialScrollIndex={Math.max(0, LENGTH_VALUES.indexOf(selectedLength))}
                getItemLayout={(_, index) => ({ length: ITEM_HEIGHT, offset: ITEM_HEIGHT * index, index })}
                onScrollEndDrag={onLengthScrollEnd}
                onMomentumScrollEnd={onLengthScrollEnd}
                renderItem={({ item }) => (
                  <Pressable onPress={() => { Haptics.selectionAsync(); setSelectedLength(item); }} style={styles.weightItem}>
                    <Text style={[styles.weightItemText, selectedLength === item && styles.weightItemTextActive]}>{item} см</Text>
                  </Pressable>
                )}
              />
            </View>
          </Animated.View>
        </View>
      </Modal>

      {/* Height Picker Modal */}
      <Modal visible={showHeightPicker} animationType="slide" transparent onRequestClose={() => setShowHeightPicker(false)}>
        <View style={styles.modalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setShowHeightPicker(false)} />
          <Animated.View entering={FadeInDown.springify()} style={[styles.modalSheet, styles.weightModalSheet]}>
            <View {...heightPanResponder.panHandlers} style={styles.handleWrap}>
              <View style={styles.modalHandle} />
            </View>
            <View style={styles.modalHeader}>
              <Pressable onPress={() => setShowHeightPicker(false)}>
                <Text style={styles.modalCancel}>{language === "uk" ? "Скасувати" : "Cancel"}</Text>
              </Pressable>
              <Text style={styles.modalTitle}>{language === "uk" ? "Висота" : "Height"}</Text>
              <Pressable onPress={confirmHeight}>
                <Text style={styles.modalSave}>{language === "uk" ? "Зберегти" : "Save"}</Text>
              </Pressable>
            </View>
            <View style={styles.weightPickerContainer}>
              <View style={styles.weightSelectionBar} />
              <FlatList
                data={HEIGHT_VALUES}
                keyExtractor={(item) => item}
                showsVerticalScrollIndicator={false}
                snapToInterval={ITEM_HEIGHT}
                decelerationRate="fast"
                contentContainerStyle={{ paddingVertical: ITEM_HEIGHT * 2 }}
                initialScrollIndex={Math.max(0, HEIGHT_VALUES.indexOf(selectedHeight))}
                getItemLayout={(_, index) => ({ length: ITEM_HEIGHT, offset: ITEM_HEIGHT * index, index })}
                onScrollEndDrag={onHeightScrollEnd}
                onMomentumScrollEnd={onHeightScrollEnd}
                renderItem={({ item }) => (
                  <Pressable onPress={() => { Haptics.selectionAsync(); setSelectedHeight(item); }} style={styles.weightItem}>
                    <Text style={[styles.weightItemText, selectedHeight === item && styles.weightItemTextActive]}>{item} см</Text>
                  </Pressable>
                )}
              />
            </View>
          </Animated.View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  topBar: {
    backgroundColor: Colors.surface,
  },
  scrollContent: { padding: 20, paddingBottom: 120 },
  photoButton: { alignSelf: "center", marginBottom: 28, position: "relative" },
  photoPreview: { width: 110, height: 110, borderRadius: 55 },
  photoPlaceholder: {
    width: 110, height: 110, borderRadius: 55,
    backgroundColor: Colors.primaryLight, alignItems: "center",
    justifyContent: "center", gap: 6,
    borderWidth: 2, borderColor: Colors.border, borderStyle: "dashed",
  },
  photoPlaceholderText: { fontSize: 11, fontFamily: "Inter_500Medium", color: Colors.primary },
  photoBadge: {
    position: "absolute", bottom: 4, right: 4,
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: Colors.primary, alignItems: "center", justifyContent: "center",
    borderWidth: 2, borderColor: Colors.surface,
  },
  section: { marginBottom: 20 },
  sectionTitle: {
    fontSize: 12, fontFamily: "Inter_600SemiBold", color: Colors.textSecondary,
    textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 10, marginLeft: 4,
  },
  mainSpeciesRow: { flexDirection: "row", gap: 10 },
  mainSpeciesBtn: {
    flex: 1, alignItems: "center", justifyContent: "center",
    paddingVertical: 16, paddingHorizontal: 6,
    backgroundColor: Colors.surface, borderRadius: 18,
    borderWidth: 2, borderColor: Colors.border,
    gap: 6, minHeight: 86,
    shadowColor: Colors.shadow, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1, shadowRadius: 6, elevation: 2,
  },
  mainSpeciesBtnActive: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primaryLight,
  },
  mainSpeciesEmoji: { fontSize: 30 },
  mainSpeciesLabel: {
    fontSize: 12, fontFamily: "Inter_600SemiBold",
    color: Colors.textSecondary, textAlign: "center",
  },
  mainSpeciesLabelActive: { color: Colors.primary },
  genderRow: { flexDirection: "row", gap: 12 },
  genderOption: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    paddingVertical: 14, borderRadius: 14,
    backgroundColor: Colors.surface, borderWidth: 2, borderColor: Colors.border,
  },
  genderMaleActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  genderFemaleActive: { backgroundColor: "#E91E63", borderColor: "#E91E63" },
  genderLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: Colors.textSecondary },
  genderLabelActive: { color: Colors.textLight },
  card: {
    backgroundColor: Colors.surface, borderRadius: 18, overflow: "hidden",
    borderWidth: 1, borderColor: Colors.border,
    shadowColor: Colors.shadow, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1, shadowRadius: 12, elevation: 3,
  },
  inputGroup: { paddingHorizontal: 16, paddingVertical: 14 },
  inputLabel: { fontSize: 11, fontFamily: "Inter_500Medium", color: Colors.textTertiary, marginBottom: 4 },
  input: { fontSize: 15, fontFamily: "Inter_400Regular", color: Colors.text, padding: 0 },
  pickerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  divider: { height: 1, backgroundColor: Colors.border, marginLeft: 16 },
  saveButton: {
    backgroundColor: Colors.primary, borderRadius: 18, paddingVertical: 17,
    alignItems: "center", marginTop: 8,
    shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35, shadowRadius: 14, elevation: 6,
  },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: Colors.textLight },
  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.4)" },
  modalSheet: {
    backgroundColor: Colors.surface, borderTopLeftRadius: 28, borderTopRightRadius: 28,
    borderWidth: 1, borderColor: Colors.border, maxHeight: "70%",
  },
  weightModalSheet: { maxHeight: "55%" },
  handleWrap: { paddingTop: 12, paddingBottom: 4, alignItems: "center" },
  modalCancel: { fontSize: 15, fontFamily: "Inter_400Regular", color: Colors.textSecondary },
  modalSave: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: Colors.primary },
  modalHandle: {
    width: 40, height: 4, borderRadius: 2,
    backgroundColor: Colors.border,
  },
  modalHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  modalTitle: { fontSize: 18, fontFamily: "Inter_700Bold", color: Colors.text },
  breedRow: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingVertical: 15,
  },
  breedRowActive: { backgroundColor: Colors.primaryLight },
  breedText: { fontSize: 15, fontFamily: "Inter_400Regular", color: Colors.text },
  breedTextActive: { fontFamily: "Inter_600SemiBold", color: Colors.primary },
  breedSeparator: { height: 1, backgroundColor: Colors.border, marginLeft: 20 },
  weightPickerContainer: { position: "relative", height: 220 },
  weightSelectionBar: {
    position: "absolute", top: "50%", left: 0, right: 0,
    height: ITEM_HEIGHT, marginTop: -ITEM_HEIGHT / 2,
    backgroundColor: Colors.primaryLight, borderRadius: 12, marginHorizontal: 16,
  },
  weightItem: { height: ITEM_HEIGHT, justifyContent: "center", alignItems: "center" },
  weightItemText: { fontSize: 20, fontFamily: "Inter_400Regular", color: Colors.textSecondary },
  weightItemTextActive: { fontSize: 22, fontFamily: "Inter_700Bold", color: Colors.primary },
});
