import { MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";

export default function ForgotPasswordScreen() {
  const { forgotPassword } = useAuth();
  const { t } = useLanguage();
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSend = async () => {
    if (!email.trim()) {
      Alert.alert("", t.errorEmail);
      return;
    }
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const { error } = await forgotPassword(email);
    setLoading(false);
    if (error) {
      Alert.alert(t.error, error);
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setSent(true);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: "#FFFAF6" }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <LinearGradient
        colors={["#52280D", "#3D1C02"]}
        style={[styles.header, { paddingTop: insets.top + 12 }]}
      >
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <MaterialCommunityIcons name="arrow-left" size={22} color="#FFFAF6" />
        </Pressable>
        <Text style={styles.headerTitle}>{t.forgotPasswordTitle}</Text>
        <View style={{ width: 40 }} />
      </LinearGradient>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {sent ? (
          <Animated.View entering={FadeInDown.delay(40).springify()} style={styles.successCard}>
            <Text style={styles.successEmoji}>📧</Text>
            <Text style={styles.successTitle}>{t.forgotPasswordSuccess}</Text>
            <Text style={styles.successText}>{t.forgotPasswordSuccessText(email)}</Text>
            <Pressable onPress={() => router.back()} style={styles.backToLoginBtn}>
              <LinearGradient colors={["#E8651A", "#C45215"]} style={styles.backToLoginGrad}>
                <Text style={styles.backToLoginText}>{t.forgotPasswordBack}</Text>
              </LinearGradient>
            </Pressable>
          </Animated.View>
        ) : (
          <Animated.View entering={FadeInDown.delay(80).springify()} style={styles.content}>
            <Text style={styles.title}>{t.forgotPasswordHeading}</Text>
            <Text style={styles.subtitle}>{t.forgotPasswordSubtitle}</Text>

            <View style={styles.card}>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Email</Text>
                <View style={styles.inputWrap}>
                  <MaterialCommunityIcons name="email-outline" size={18} color="#C4956A" />
                  <TextInput
                    style={styles.input}
                    value={email}
                    onChangeText={setEmail}
                    placeholder="your@email.com"
                    placeholderTextColor="#C4A882"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    autoComplete="email"
                    autoCorrect={false}
                    returnKeyType="go"
                    onSubmitEditing={handleSend}
                  />
                </View>
              </View>
            </View>

            <Pressable onPress={handleSend} disabled={loading} style={styles.ctaWrap}>
              <LinearGradient colors={["#E8651A", "#C45215"]} style={styles.cta}>
                <Text style={styles.ctaText}>
                  {loading ? t.forgotPasswordSending : t.forgotPasswordBtn}
                </Text>
              </LinearGradient>
            </Pressable>

            <Pressable onPress={() => router.back()} style={styles.backLink}>
              <Text style={styles.backLinkText}>← {t.forgotPasswordBack}</Text>
            </Pressable>
          </Animated.View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 12, paddingBottom: 20,
  },
  backBtn: { padding: 8, minWidth: 40 },
  headerTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", color: "#FFFAF6" },
  scroll: { padding: 24, flexGrow: 1 },
  content: { gap: 16 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold", color: "#3D1C02", marginTop: 8 },
  subtitle: { fontSize: 14, fontFamily: "Inter_400Regular", color: "#7A5C40", lineHeight: 21 },
  card: {
    backgroundColor: "#FFFFFF", borderRadius: 20, overflow: "hidden",
    borderWidth: 1, borderColor: "#F0E4D6",
    shadowColor: "#3D1C02", shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 12, elevation: 3,
  },
  inputGroup: { paddingHorizontal: 18, paddingVertical: 16 },
  label: { fontSize: 11, fontFamily: "Inter_500Medium", color: "#A07850", marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.6 },
  inputWrap: { flexDirection: "row", alignItems: "center", gap: 10 },
  input: { fontSize: 15, fontFamily: "Inter_400Regular", color: "#3D1C02", padding: 0, flex: 1 },
  ctaWrap: {
    borderRadius: 18, overflow: "hidden",
    shadowColor: "#E8651A", shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35, shadowRadius: 14, elevation: 6,
  },
  cta: { paddingVertical: 17, alignItems: "center" },
  ctaText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#FFFAF6" },
  backLink: { alignItems: "center", paddingVertical: 8 },
  backLinkText: { fontSize: 14, fontFamily: "Inter_500Medium", color: "#E8651A" },
  successCard: {
    gap: 16, paddingTop: 60, alignItems: "center",
  },
  successEmoji: { fontSize: 72 },
  successTitle: { fontSize: 26, fontFamily: "Inter_700Bold", color: "#3D1C02" },
  successText: { fontSize: 15, fontFamily: "Inter_400Regular", color: "#7A5C40", textAlign: "center", lineHeight: 23 },
  backToLoginBtn: {
    borderRadius: 18, overflow: "hidden", marginTop: 12, alignSelf: "stretch",
    shadowColor: "#E8651A", shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35, shadowRadius: 14, elevation: 6,
  },
  backToLoginGrad: { paddingVertical: 17, alignItems: "center" },
  backToLoginText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#FFFAF6" },
});
